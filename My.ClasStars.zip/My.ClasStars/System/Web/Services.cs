﻿namespace System.Web
{
    internal class Services
    {
    }
}