﻿using SharedTypes;
using System.Linq;

namespace My.ClasStars;

public static class AppInfo
{
    public static LoginResultUser UserInfo { get; set; }
    public static bool PowerUser { get; set; }
    public static bool AdminUser { get; set; }
}